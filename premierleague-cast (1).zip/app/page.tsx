import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mic, PlayCircle, Rss } from "lucide-react";

export default function PremierLeaguePodcast() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-purple-900 text-white p-6">
      <header className="text-center py-12">
        <h1 className="text-5xl font-bold uppercase tracking-widest text-purple-400">
          Premier League Cast
        </h1>
        <p className="text-lg mt-4 max-w-xl mx-auto">
          Your bold and creative source for Premier League podcasts. Live commentary, match analysis, and passionate fan debates every game of the 2025/2026 season.
        </p>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 px-4 md:px-12">
        {[1, 2, 3].map((episode) => (
          <Card key={episode} className="bg-gray-800 border-purple-500 border shadow-xl">
            <CardContent>
              <h2 className="text-xl font-bold mb-2">Episode {episode}</h2>
              <p className="text-sm text-gray-300 mb-4">
                Matchday recap, tactical breakdown, and bold opinions from passionate fans.
              </p>
              <Button className="w-full flex gap-2 items-center bg-purple-600 hover:bg-purple-500">
                <PlayCircle className="w-5 h-5" /> Listen Now
              </Button>
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="mt-16 text-center max-w-xl mx-auto">
        <h3 className="text-3xl font-bold mb-4">Subscribe to Our Podcast</h3>
        <p className="text-gray-300 mb-4">Never miss a match. Get episodes delivered directly to your feed.</p>
        <div className="flex gap-2 justify-center">
          <Input placeholder="Enter your email" className="w-full max-w-xs" />
          <Button className="bg-purple-600 hover:bg-purple-500">Subscribe</Button>
        </div>
      </section>

      <footer className="mt-20 text-center text-gray-500 text-sm">
        <div className="flex justify-center gap-6 mb-2">
          <a href="#" className="hover:text-white flex items-center gap-1"><Mic className="w-4 h-4" /> Spotify</a>
          <a href="#" className="hover:text-white flex items-center gap-1"><Rss className="w-4 h-4" /> RSS Feed</a>
        </div>
        &copy; 2025 Premier League Cast. All rights reserved.
      </footer>
    </div>
  );
}
