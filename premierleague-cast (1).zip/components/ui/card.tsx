import * as React from "react";

const Card = ({ children, className }) => {
  return <div className={`rounded-2xl overflow-hidden ${className}`}>{children}</div>;
};

const CardContent = ({ children, className }) => {
  return <div className={`p-6 ${className}`}>{children}</div>;
};

export { Card, CardContent };
